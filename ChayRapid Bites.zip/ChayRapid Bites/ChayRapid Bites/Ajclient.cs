﻿using ChayRapid_Bites.ADO;
using ChayRapid_Bites.metier;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChayRapid_Bites
{
    public partial class Ajclient : UserControl
    {
        public Ajclient()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            Client C = new Client
            {
                CIN_Cl = Int64.Parse(textBox1.Text),
                Nom_Cl = textBox2.Text,
                Pren_Cl = textBox3.Text,
                Ville_Cl = textBox4.Text,
                Tel_Cl = Int64.Parse(textBox5.Text),
            };
            ClientADO CA = new ClientADO();
            CA.Inserer(C);
            MessageBox.Show("Enregistrement ajouté avec succès!");


        }
    }
}
