﻿using ChayRapid_Bites.ADO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChayRapid_Bites
{
    public partial class login : UserControl
    {
        public login()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(isvalid())
            {
                Connexion.Ouvrir();
                using (Connexion.cn)
                {
                    DataTable dta=new DataTable();
                
                    SqlDataAdapter sda = new SqlDataAdapter("select * from [user] where username='" + textBox1.Text.Trim() + "' and password ='" + textBox2.Text.Trim() + "'", Connexion.cn);

                    sda.Fill(dta);
                    if(dta.Rows.Count==1)
                    {
                        Fadmin fa = new Fadmin();
                        this.Hide();
                        fa.Show();


                    }

                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }
        private bool isvalid()
        {
            if (textBox1.Text.TrimStart()==string.Empty)
            {
                MessageBox.Show("enter valid user name","error");
                return false;
            }
            else if(textBox2.Text.TrimStart()==string.Empty){
                MessageBox.Show("enter valid password", "error");
                return false;
            }
            return true;
        }

        private void login_Load(object sender, EventArgs e)
        {
            Connexion.Ouvrir();
            login l = new login();
        }
    }
}
