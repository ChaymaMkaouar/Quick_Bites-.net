﻿using ChayRapid_Bites.ADO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChayRapid_Bites
{
    public partial class Fadmin : Form
    {
        public object C { get; internal set; }

        public Fadmin()
        {
            InitializeComponent();
            admin1.BringToFront();
        }

        private void Fadmin_Load(object sender, EventArgs e)
        {
            ADO.Connexion.Ouvrir();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            admin1.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            product1.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            menu21.BringToFront();
        }
    }
}
