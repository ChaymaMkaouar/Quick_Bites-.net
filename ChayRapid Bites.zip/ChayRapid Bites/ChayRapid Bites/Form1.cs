﻿using ChayRapid_Bites.ADO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChayRapid_Bites
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SidePanel.Height = button1.Height;
            SidePanel.Top = button1.Top;
            fisrtCostSercs1.BringToFront();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SidePanel.Height = button1.Height;
            SidePanel.Top = button1.Top;
            fisrtCostSercs1.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SidePanel.Height = button2.Height;
            SidePanel.Top = button2.Top;
            costSec1.BringToFront();
        }

      

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void admin1_Load(object sender, EventArgs e)
        {
            ADO.Connexion.Ouvrir();
            MessageBox.Show(Connexion.cn.State.ToString());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ADO.Connexion.Ouvrir();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SidePanel.Height = button3.Height;
            SidePanel.Top = button3.Top;
            collection1.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SidePanel.Height = button4.Height;
            SidePanel.Top = button4.Top;
            delivary1.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SidePanel.Height = button5.Height;
            SidePanel.Top = button5.Top;
            menu1.BringToFront();
        }

       

        private void pictureBox7_Click(object sender, EventArgs e)
        {
          
            login1.BringToFront();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            ques1.BringToFront();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            acctualité1.BringToFront();
        }
    }
}
