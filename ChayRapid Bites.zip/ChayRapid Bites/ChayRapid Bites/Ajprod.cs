﻿using ChayRapid_Bites.ADO;
using ChayRapid_Bites.metier;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace ChayRapid_Bites
{
    public partial class Ajprod : UserControl
    {
        public object Num_Cde { get; internal set; }
        public object CIN_Cl { get; internal set; }
        public object Date_Cde { get; internal set; }

        public Ajprod()
        {
            InitializeComponent();
           
            
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
          
        }

      





       

      

        public Produit PP;
        private void button1_Click(object sender, EventArgs e)
        {

            Produit P = new Produit
            {
                Ref_Prod = textBox1.Text,
                Desig_Prod = textBox2.Text,
                Categ_Prod = textBox3.Text,
                PrixV_Prod = decimal.Parse(textBox4.Text),
                Qte_Stock = int.Parse(textBox5.Text),
                
                
            };
            produitADO PA = new produitADO();
         
                    PA.Inserer(P);
                    MessageBox.Show("Enregistrement ajouté avec succès!");
                  

            
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Ajprod_Load(object sender, EventArgs e)
        {

          
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}




