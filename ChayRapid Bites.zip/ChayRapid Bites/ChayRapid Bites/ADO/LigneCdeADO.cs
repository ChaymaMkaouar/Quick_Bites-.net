﻿using ChayRapid_Bites.metier;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChayRapid_Bites.ADO
{
    internal class LigneCdeADO
    {
        public void Inserer(LigneCde C)
        {
            SqlCommand cmdaj = new SqlCommand("insert into LigneCommande (Num_Cde, Ref_Prod, Qte) values(@Num, @Ref, @Qte)",
            Connexion.cn);
            cmdaj.Parameters.AddWithValue("@Num", C.Num_Cde);
            cmdaj.Parameters.AddWithValue("@Ref", C.Ref_Prod);
            cmdaj.Parameters.AddWithValue("@Qte", C.Qte);
            cmdaj.ExecuteNonQuery();
        }
        public void Modifier(LigneCde C)
        {
            SqlCommand cmdaj = new SqlCommand("update LigneCommande set Qte=@Qte where Num_Cde = @Num and Ref_Prod = @Ref", Connexion.cn);
            cmdaj.Parameters.AddWithValue("@Qte", C.Qte);
            cmdaj.Parameters.AddWithValue("@Num", C.Num_Cde);
            cmdaj.Parameters.AddWithValue("@Ref", C.Ref_Prod);
            cmdaj.ExecuteNonQuery();
        }
        public void Supprimer(Int64 Num)
        {
            SqlCommand cmdaj = new SqlCommand("delete from LigneCommande where Num_Cde = @Num ", Connexion.cn);
            cmdaj.Parameters.AddWithValue("@Num", Num);
            cmdaj.ExecuteNonQuery();
        }
        public static DataTable Liste_Lig_Cde(Int64 Num)
        {
         DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select l.Num_Cde,l.Ref_Prod, p.Desig_Prod, p.PrixV_Prod, l.Qte, l.Qte * p.PrixV_Prod as Total from LigneCommande l, Produit p where l.Num_Cde = @Num and p.Ref_Prod = l.Ref_Prod ", Connexion.cn);
            da.SelectCommand.Parameters.AddWithValue("@Num", Num);
            da.Fill(dtcl);
            return dtcl;
        }
    }

}

