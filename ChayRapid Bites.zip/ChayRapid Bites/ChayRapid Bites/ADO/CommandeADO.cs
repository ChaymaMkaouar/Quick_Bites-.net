﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChayRapid_Bites.ADO
{
    internal class CommandeADO
    {
        public void Inserer(Ajprod Co)
        {
            SqlCommand cmdaj = new SqlCommand("insert into Commande (Num_Cde, CIN_Cl, Date_Cde) values(@Num, @Cin, @Date)",
            Connexion.cn);
            cmdaj.Parameters.AddWithValue("@Num", Co.Num_Cde);
            cmdaj.Parameters.AddWithValue("@Cin", Co.CIN_Cl);
            cmdaj.Parameters.AddWithValue("@Date", Co.Date_Cde);
            cmdaj.ExecuteNonQuery();
        }
        public void Supprimer(Int64 Cin)
        {
            string req = "delete from client where CIN_CL = @Cin";
            SqlCommand cmdsupp = new SqlCommand(req, Connexion.cn);
            cmdsupp.Parameters.AddWithValue("@Cin", Cin);
            cmdsupp.ExecuteNonQuery();
        }
        public static bool Existe_Cde(Int64 Num)
        {
            SqlCommand cverif = new SqlCommand("select *from commande where Num_Cde= @Num", Connexion.cn);
            cverif.Parameters.AddWithValue("@Num", Num);
            SqlDataReader drverif = cverif.ExecuteReader();
            if (drverif.HasRows == true)
         {
                drverif.Close();
                return true;
            }
            else
            {
                drverif.Close();
                return false;
            }
        }
        public static DataTable Liste_Cde(Int64 NCde)
        {
            DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select qcl.* from client qcl, Commande c where qcl.CIN_Cl=c.CIN_CL and c.Num_Cde=@Num", Connexion.cn);
            da.SelectCommand.Parameters.AddWithValue("@Num", NCde);
            da.Fill(dtcl);
            return dtcl;
        }
    }
}

