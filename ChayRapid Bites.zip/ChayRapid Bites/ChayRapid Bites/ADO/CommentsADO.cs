﻿using ChayRapid_Bites.metier;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChayRapid_Bites.ADO
{
    internal class CommentsADO
    {
        public void Inserer(Comments Com)
        {
            SqlCommand cmdaj = new SqlCommand("INSERT INTO comments (id,Contenu) VALUES (@id,@Contenu)", Connexion.cn);
            cmdaj.Parameters.AddWithValue("@id", Com.id);
            cmdaj.Parameters.AddWithValue("@Contenu", Com.Contenu);
            cmdaj.ExecuteNonQuery();
        }
    }
}
