﻿using ChayRapid_Bites.metier;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChayRapid_Bites.ADO
{
    internal class produitADO
    {
        public void Inserer(Produit P)
        {
            SqlCommand cmdaj = new SqlCommand("insert into Produit(Ref_Prod,Desig_Prod,Categ_Prod,PrixV_Prod) values (@Ref,@Des,@Cat,@Prix)", Connexion.cn);
            cmdaj.Parameters.AddWithValue("@Ref", P.Ref_Prod);
            cmdaj.Parameters.AddWithValue("@Des", P.Desig_Prod);
            cmdaj.Parameters.AddWithValue("@Cat", P.Categ_Prod);
            cmdaj.Parameters.AddWithValue("@Prix", P.PrixV_Prod);
            MessageBox.Show("Opération d'insertion effectuée avec succès!");
            cmdaj.ExecuteNonQuery();
        }
        public static bool Existe_Produit(String Ref)
        {
            SqlCommand cverif = new SqlCommand("select * from Produit where Ref_Prod = @Ref", Connexion.cn);
            cverif.Parameters.AddWithValue("@Ref", Ref);
            SqlDataReader drverif = cverif.ExecuteReader();
            if (drverif.HasRows == true)
            {
                drverif.Close();
                return true;
            }
            else
            {
                drverif.Close();
                return false;
            }
        }
        public void Supprimer(String Ref)
        {
            string req = "delete from Produit where Ref_Prod = @Ref";
            SqlCommand cmdsupp = new SqlCommand(req, Connexion.cn);
            cmdsupp.Parameters.AddWithValue("@Ref", Ref);
            cmdsupp.ExecuteNonQuery();
        }
        public void Modifier(Produit P)
        {
            string req = "update Produit set Ref_Prod=@Ref,Desig_Prod=@Des, Categ_Prod=@Cat, PrixV_Prod=@Prix where Ref_Prod =@Ref";
            SqlCommand cmdmaj = new SqlCommand(req, Connexion.cn);
            cmdmaj.Parameters.AddWithValue("@Ref", P.Ref_Prod);
            cmdmaj.Parameters.AddWithValue("@Des", P.Desig_Prod);
            cmdmaj.Parameters.AddWithValue("@Cat", P.Categ_Prod);
            cmdmaj.Parameters.AddWithValue("@Prix", P.PrixV_Prod);
            cmdmaj.ExecuteNonQuery();
        }

        public static DataTable Liste_Produit()
        {
            DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select * from Produit", Connexion.cn);
            da.Fill(dtcl);
            return dtcl;
        }
        public static DataTable Liste_Client(String Ref)
        {
            DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select * from Produit where Ref_Prod=@Ref", Connexion.cn);
            da.SelectCommand.Parameters.AddWithValue("@Ref", Ref);
            da.Fill(dtcl);
            return dtcl;
        }
        public static DataTable Liste_Produit_Cde(Int64 NCde)
        {
            DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select qcl.* from Produit qcl, Commande c where cl.Ref_Prod=c.Ref_Prod and c.Num_Cde=@Num", Connexion.cn);
            da.SelectCommand.Parameters.AddWithValue("@Num", NCde);
            da.Fill(dtcl);
            return dtcl;
        }
    }
}
