﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChayRapid_Bites.ADO
{
    public partial class ques : UserControl
    {
        public ques()
        {
            InitializeComponent();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private void ques_Load(object sender, EventArgs e)
        {
            Connexion.Ouvrir();
        }

        private void EnvoyerCommentaireEnBaseDeDonnees(string commentaire)
        {
            try
            {
               
                using (Connexion.cn)
                {
                    // Ouvrir la connexion
                    Connexion.Ouvrir();

                    // Définir la commande SQL pour insérer le commentaire dans la base de données
                    string commandeSql = "INSERT INTO comments (Contenu) VALUES (@Contenu)";
                    using (SqlCommand commande = new SqlCommand(commandeSql, Connexion.cn))
                    {
                        // Ajouter le paramètre pour le commentaire
                        commande.Parameters.AddWithValue("@Contenu", commentaire);

                        // Exécuter la commande
                        commande.ExecuteNonQuery();

                        MessageBox.Show("Le commentaire a été envoyé avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Effacer le TextBox après l'envoi
                        textBox1.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Une erreur s'est produite : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        } 


            private void button1_Click(object sender, EventArgs e)
        {
            string commentaire = textBox1.Text;

            // Vérifier si le commentaire n'est pas vide
            if (!string.IsNullOrEmpty(commentaire))
            {
                // Appeler la méthode pour envoyer le commentaire à la base de données
                EnvoyerCommentaireEnBaseDeDonnees(commentaire);
            }
            else
            {
                MessageBox.Show("Veuillez entrer un commentaire avant d'envoyer.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
