﻿using ChayRapid_Bites.ADO;
using ChayRapid_Bites.metier;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ChayRapid_Bites
{
    public partial class Product : UserControl
    {
        internal Produit P { get; set; }

        public Product()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            if (produitADO.Existe_Produit(textBox1.Text))
            {
                MessageBox.Show(this, "\n\nProduit déjà existant", "attention!!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Produit P = new Produit
                {
                    Ref_Prod   = textBox1.Text,
                    Desig_Prod = textBox2.Text,
                    Categ_Prod = textBox3.Text,
                    PrixV_Prod = decimal.Parse(textBox4.Text),

                };
                produitADO PO = new produitADO();
                PO.Inserer(P);
                dataGridView1.DataSource = produitADO.Liste_Produit();
            }
        }

        private void Product_Load(object sender, EventArgs e)
        {
            Connexion.Ouvrir();
           
            dataGridView1.DataSource = produitADO.Liste_Produit();
            Product product = new Product();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int ind = dataGridView1.CurrentRow.Index;
            textBox1.Text = dataGridView1[0, ind].Value.ToString();
            textBox2.Text = dataGridView1[1, ind].Value.ToString();
            textBox3.Text = dataGridView1[2, ind].Value.ToString();
            textBox4.Text = dataGridView1[3, ind].Value.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
            Produit P = new Produit
            {
                Ref_Prod =textBox1.Text,
                Desig_Prod = textBox2.Text,
                Categ_Prod = textBox3.Text,
                PrixV_Prod = decimal.Parse(textBox4.Text),
            };
            produitADO Po = new produitADO();
            Po.Modifier(P);
            dataGridView1.DataSource = produitADO.Liste_Produit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DialogResult rep = MessageBox.Show(this, "\n\nVoulez vous confirmer la suppression ", "Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (rep == DialogResult.Yes)
            {
                produitADO PA = new produitADO();
                PA.Supprimer(textBox1.Text);
                dataGridView1.DataSource = produitADO.Liste_Produit();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            DataTable dtc = produitADO.Liste_Produit();
            if (dtc.Rows.Count == 0)
            {
                MessageBox.Show(this, "Client inexistant");
            }
            else
            {
                textBox2.Text = dtc.Rows[0][1].ToString();
                textBox3.Text = dtc.Rows[0][2].ToString();
                textBox4.Text = dtc.Rows[0][1].ToString();
            }
        }

        
    }
    }

