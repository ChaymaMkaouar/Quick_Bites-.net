﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChayRapid_Bites.metier
{
    internal class Commande
    {
        public Int64 Num_Cde { get; set; }
        public Int64 CIN_Cl { get; set; }
        public DateTime Date_Cde { get; set; }
        public Commande() { }

    }
}
