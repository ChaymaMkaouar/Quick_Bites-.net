﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChayRapid_Bites.metier
{
    internal class Comments
    {
        public Int64 id { get; set; }
        public String Contenu { get; set; }
    }
}
