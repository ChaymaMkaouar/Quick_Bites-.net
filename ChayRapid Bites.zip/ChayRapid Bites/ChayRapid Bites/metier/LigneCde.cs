﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChayRapid_Bites.metier
{
    internal class LigneCde
    {
        public Int64 Num_Cde { get; set; }
        public Int64 Ref_Prod { get; set; }
        public int Qte { get; set; }
        public LigneCde() { }

        
    }
}
