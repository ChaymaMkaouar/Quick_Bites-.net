﻿
using ChayRapid_Bites.ADO;
using ChayRapid_Bites.metier;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChayRapid_Bites
{
    public partial class Admin : UserControl
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            if (ClientADO.Existe_Client(Int64.Parse(cin.Text)))
            {
                MessageBox.Show(this, "\n\nClient déjà existant", "attention!!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Client C = new Client
                {
                    CIN_Cl = Int64.Parse(cin.Text),
                    Nom_Cl = textBox2.Text,
                    Pren_Cl = textBox3.Text,
                    Ville_Cl = textBox4.Text,
                    Tel_Cl = Int64.Parse(textBox5.Text),
                };
                ClientADO CA = new ClientADO();
                CA.Inserer(C);
                dataGridView1.DataSource = ClientADO.Liste_Client();
            }
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            Connexion.Ouvrir();
            
            dataGridView1.DataSource = ClientADO.Liste_Client();
            Admin A = new Admin();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int ind = dataGridView1.CurrentRow.Index;
            cin.Text = dataGridView1[0, ind].Value.ToString();
            textBox2.Text = dataGridView1[1, ind].Value.ToString();
            textBox3.Text = dataGridView1[2, ind].Value.ToString();
            textBox4.Text = dataGridView1[3, ind].Value.ToString();
            textBox5.Text = dataGridView1[4, ind].Value.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Client C = new Client
            {
                CIN_Cl = Int64.Parse(cin.Text),
                Nom_Cl = textBox2.Text,
                Pren_Cl = textBox3.Text,
                Ville_Cl = textBox4.Text,
                Tel_Cl = Int64.Parse(textBox5.Text),
            };
            ClientADO CA = new ClientADO();
            CA.Modifier(C);
            dataGridView1.DataSource = ClientADO.Liste_Client();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DialogResult rep = MessageBox.Show(this, "\n\nVoulez vous confirmer la suppression ", "Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (rep == DialogResult.Yes)
            {
                ClientADO CA = new ClientADO();
                CA.Supprimer(Int32.Parse(cin.Text));
                dataGridView1.DataSource = ClientADO.Liste_Client();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            DataTable dtc = ClientADO.Liste_Client(Int64.Parse(cin.Text));
            if (dtc.Rows.Count == 0)
            {
                MessageBox.Show(this, "Client inexistant");
            }
            else
            {
                textBox2.Text = dtc.Rows[0][1].ToString();
                textBox3.Text = dtc.Rows[0][2].ToString();
                textBox4.Text = dtc.Rows[0][3].ToString();
                textBox5.Text = dtc.Rows[0][1].ToString();
            }
        }
    }
}
